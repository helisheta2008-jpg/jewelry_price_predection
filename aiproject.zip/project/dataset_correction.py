# =============================================================
#  DATASET PREPARATION
#  Raw dataset (Dataset/jewelry.csv, 95,911 records)
#      -> final dataset (Dataset/dataset.csv, 9,000 records, 10 columns)
# =============================================================
import os
import warnings

import pandas as pd

warnings.filterwarnings("ignore")

# ---------- locate project folder (works from any working directory) ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = None
for folder in [os.path.dirname(SCRIPT_DIR), SCRIPT_DIR, os.getcwd(), os.path.dirname(os.getcwd())]:
    if os.path.exists(os.path.join(folder, "Dataset", "jewelry.csv")):
        BASE_DIR = folder
        break
if BASE_DIR is None:
    raise FileNotFoundError("Dataset/jewelry.csv not found. Keep the Dataset folder next to Python_Code.")

RAW_PATH = os.path.join(BASE_DIR, "Dataset", "jewelry.csv")
FINAL_PATH = os.path.join(BASE_DIR, "Dataset", "dataset.csv")

print("imported")

# ---------- 1. Load raw dataset ----------
df = pd.read_csv(RAW_PATH)
df.columns = df.columns.str.strip()          # remove extra spaces from column names
print("Raw dataset shape            :", df.shape)
print("Raw duplicate rows           :", int(df.duplicated().sum()))
print("Raw missing values (total)   :", int(df.isnull().sum().sum()))

# ---------- 2. Remove duplicate rows ----------
df = df.drop_duplicates()
print("After removing duplicates    :", df.shape)

# ---------- 3. Price is the target -> remove rows where Price is missing ----------
df["Price"] = pd.to_numeric(df["Price"], errors="coerce")
df = df.dropna(subset=["Price"])
print("After removing missing Price :", df.shape)

# ---------- 4. Keep only jewellery rows (remove electronics.clocks and shifted/corrupt rows) ----------
is_jewellery = df["Category.alias"].isna() | df["Category.alias"].astype(str).str.startswith("jewelry.")
df = df[is_jewellery]
print("After jewellery filter       :", df.shape)

# ---------- 5. Remove Price outliers (IQR method, on the full data) ----------
Q1 = df["Price"].quantile(0.25)
Q3 = df["Price"].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR
print(f"Price IQR limits             : {lower:.2f} to {upper:.2f}")
df = df[(df["Price"] >= lower) & (df["Price"] <= upper)]
print("After removing outliers      :", df.shape)

# ---------- 6. Count null values per row ----------
null_count_per_row = df.isnull().sum(axis=1)

# Dataset is divided into two parts to control the number of null values
clean_rows = df[null_count_per_row == 0]              # rows with no null value
rows_with_1_null = df[null_count_per_row == 1]        # rows with exactly one null value
print("\nClean rows available         :", clean_rows.shape[0])
print("Rows with exactly 1 null     :", rows_with_1_null.shape[0])

# ---------- 7. Final dataset = 8980 clean rows + 20 rows with 1 null value ----------
null_sample = rows_with_1_null.sample(n=20, random_state=42)
clean_sample = clean_rows.sample(n=8980, random_state=42)

df_final = pd.concat([clean_sample, null_sample], ignore_index=True)
df_final = df_final.sample(frac=1, random_state=42).reset_index(drop=True)   # shuffle

print("\nFINAL shape                  :", df_final.shape)
print("Total null values in final   :", int(df_final.isnull().sum().sum()))

# ---------- 8. Save ----------
df_final.to_csv(FINAL_PATH, index=False)
print("\nSaved successfully ->", FINAL_PATH)
print("\nMissing values column-wise:")
print(df_final.isnull().sum())
